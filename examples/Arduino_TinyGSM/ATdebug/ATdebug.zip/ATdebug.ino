/*
  FILE: ATdebug.ino - ThingSpeak Robust Implementation
  AUTHOR: Based on ATdebug.ino by Koby Hale
  PURPOSE: Robust SIM7070G ThingSpeak integration with power management
  DESCRIPTION: Sends data to ThingSpeak every 5 minutes with full power cycle
               Uses direct AT commands without TinyGSM library
*/
#include <Arduino.h>

#define SerialAT Serial1

#define PIN_DTR     25
#define PIN_TX      27
#define PIN_RX      26
#define PWR_PIN     4


// Timing constants (milliseconds)
#define MODEM_STARTUP_DELAY     20000   // 20 seconds for modem startup
#define AT_RESPONSE_TIMEOUT     15000   // 15 seconds for AT responses
#define NETWORK_REG_TIMEOUT     90000   // 90 seconds for network registration
#define HTTP_TIMEOUT           45000   // 45 seconds for HTTP operations
#define CYCLE_INTERVAL         300000  // 5 minutes between cycles

// Retry constants
#define MAX_AT_RETRIES         5
#define MAX_NETWORK_RETRIES    3
#define MAX_HTTP_RETRIES       3

// ThingSpeak configuration
const char* THINGSPEAK_API_KEY = "RWE803O3NIOLIUQS";
const char* APN = "internet";

// Global variables
unsigned long lastCycleTime = 0;
bool modemPowered = false;
int cycleCount = 0;

bool reply = false;

// Function declarations
String sendATCommand(String command, unsigned long timeout = AT_RESPONSE_TIMEOUT);
String sendHTTPRequest(String command, unsigned long timeout = HTTP_TIMEOUT);
bool waitForResponse(String expectedResponse, unsigned long timeout = AT_RESPONSE_TIMEOUT);
bool performThingSpeakCycle();
bool establishNetworkConnection();
bool sendThingSpeakData();
void modem_sleep();
void modem_wake();

uint32_t dectModemBaud()
{
    static uint32_t rates[] = {115200, 57600,  38400, 19200, 9600,  74400, 74880,
                               230400, 460800, 2400,  4800,  14400, 28800
                              };

    for (uint8_t i = 0; i < sizeof(rates) / sizeof(rates[0]); i++) {
        uint32_t rate = rates[i];
        Serial.printf("[INFO]:Trying baud rate:%d\n", rate);
        SerialAT.updateBaudRate(rate);
        delay(100);
        for (int j = 0; j < 15; j++) {  // Increased attempts
            SerialAT.print("AT\r\n");
            delay(500);  // Longer delay
            String input = SerialAT.readString();
            if (input.indexOf("OK") >= 0) {
                Serial.printf("[INFO]:Modem responded at rate:%d\n", rate);
                SerialAT.println("AT+IPREX=115200");
                return rate;
            }
        }
    }
    SerialAT.updateBaudRate(115200);
    Serial.println("[ERROR]:Modem is not online!!!");
    return 0;
}


void modem_on()
{
    Serial.println("\nStarting Up Modem...");

    // Initialize serial communication
    SerialAT.begin(115200, SERIAL_8N1, PIN_RX, PIN_TX);
    delay(1000);

    // Try to communicate first - modem might already be on
    Serial.println("Testing if modem is already on...");
    for (int i = 0; i < 3; i++) {
        SerialAT.println("AT");
        delay(1000);
        if (SerialAT.available()) {
            String response = SerialAT.readString();
            if (response.indexOf("OK") >= 0) {
                Serial.println("Modem already powered on and responding");
                reply = true;
                modemPowered = true;
                return;
            }
        }
    }

    // If no response, power on the modem
    Serial.println("Powering on modem...");
    pinMode(PWR_PIN, OUTPUT);
    digitalWrite(PWR_PIN, LOW);   // Ensure it's off first
    delay(2000);
    digitalWrite(PWR_PIN, HIGH);  // Power pulse
    delay(1000);
    digitalWrite(PWR_PIN, LOW);   // Release power button
    delay(MODEM_STARTUP_DELAY);   // Wait for modem to start

    int i = 15;  // More attempts

    if(dectModemBaud() == 0){
        Serial.println("Unable to communicate with modem.");
        return;
    }

    Serial.println("\nTesting Modem Response...\n");
    Serial.println("****");
    while (i) {
        SerialAT.println("AT");
        delay(1000);  // Longer delay
        if (SerialAT.available()) {
            String r = SerialAT.readString();
            Serial.println(r);
            if ( r.indexOf("OK") >= 0 ) {
                reply = true;
                break;
            }
        }
        delay(1000);
        i--;
    }
    Serial.println("****\n");
    modemPowered = reply;
}

void modem_sleep()
{
    if (!modemPowered) return;

    Serial.println("Putting modem to sleep...");

    // Step 1: Disconnect any active connections gracefully
    sendATCommand("AT+SHDISC", 3000);
    delay(1000);

    // Step 2: Deactivate PDP context
    sendATCommand("AT+CNACT=1,0", 5000);
    delay(2000);

    // Step 3: Set DTR HIGH to prepare for sleep mode
    pinMode(PIN_DTR, OUTPUT);
    digitalWrite(PIN_DTR, HIGH);
    delay(1000);

    // Step 4: Enable sleep mode (AT+CSCLK=1)
    sendATCommand("AT+CSCLK=1", 5000);
    delay(2000);

    Serial.println("Modem entered sleep mode");

    // Verify modem is sleeping by testing communication
    Serial.println("Verifying modem sleep...");
    for (int i = 0; i < 3; i++) {
        SerialAT.println("AT");
        delay(1000);
        if (SerialAT.available()) {
            String response = SerialAT.readString();
            if (response.indexOf("OK") >= 0) {
                Serial.println("WARNING: Modem still responding, sleep may have failed");
                return;
            }
        }
    }
    Serial.println("Modem sleep verified - no response to AT commands");
}

void modem_wake()
{
    Serial.println("Waking up modem...");

    // Step 1: Set DTR LOW to wake up modem
    pinMode(PIN_DTR, OUTPUT);
    digitalWrite(PIN_DTR, LOW);
    delay(2000);  // Give modem time to wake up

    // Step 2: Disable sleep mode
    sendATCommand("AT+CSCLK=0", 5000);
    delay(1000);

    // Step 3: Test communication
    for (int i = 0; i < 5; i++) {
        SerialAT.println("AT");
        delay(1000);
        if (SerialAT.available()) {
            String response = SerialAT.readString();
            if (response.indexOf("OK") >= 0) {
                Serial.println("Modem wake up successful");
                return;
            }
        }
        Serial.printf("Wake attempt %d/5...\n", i + 1);
        delay(1000);
    }

    Serial.println("WARNING: Modem wake up may have failed");
}

String sendATCommand(String command, unsigned long timeout) {
    Serial.print("Sending: ");
    Serial.println(command);

    SerialAT.println(command);

    unsigned long startTime = millis();
    String response = "";

    while (millis() - startTime < timeout) {
        if (SerialAT.available()) {
            response += SerialAT.readString();
            if (response.indexOf("OK") >= 0 || response.indexOf("ERROR") >= 0) {
                break;
            }
        }
        delay(100);
    }

    Serial.print("Response: ");
    Serial.println(response);
    return response;
}

String sendHTTPRequest(String command, unsigned long timeout) {
    Serial.print("Sending HTTP: ");
    Serial.println(command);

    SerialAT.println(command);

    unsigned long startTime = millis();
    String response = "";
    bool gotOK = false;
    bool gotSHREQ = false;

    while (millis() - startTime < timeout) {
        if (SerialAT.available()) {
            String newData = SerialAT.readString();
            response += newData;

            if (response.indexOf("OK") >= 0) {
                gotOK = true;
            }
            if (response.indexOf("+SHREQ:") >= 0) {
                gotSHREQ = true;
            }

            // For SHREQ, we need both OK and +SHREQ response
            if (command.indexOf("SHREQ") >= 0) {
                if (gotOK && gotSHREQ) {
                    break;
                }
            } else {
                if (response.indexOf("OK") >= 0 || response.indexOf("ERROR") >= 0) {
                    break;
                }
            }
        }
        delay(100);
    }

    Serial.print("HTTP Response: ");
    Serial.println(response);
    return response;
}

bool waitForResponse(String expectedResponse, unsigned long timeout) {
    unsigned long startTime = millis();
    String response = "";

    while (millis() - startTime < timeout) {
        if (SerialAT.available()) {
            response += SerialAT.readString();
            if (response.indexOf(expectedResponse) >= 0) {
                Serial.print("Got expected response: ");
                Serial.println(response);
                return true;
            }
            if (response.indexOf("ERROR") >= 0) {
                Serial.print("Got error response: ");
                Serial.println(response);
                return false;
            }
        }
        delay(100);
    }

    Serial.println("Timeout waiting for response");
    return false;
}

void setup()
{
    Serial.begin(115200);
    Serial.println("\n=== SIM7070G ThingSpeak Robust Client ===");



    // Initialize DTR pin for sleep/wake control
    pinMode(PIN_DTR, OUTPUT);
    digitalWrite(PIN_DTR, LOW); // Start with DTR LOW (awake state)

    // Don't initialize SerialAT here - let modem_on() handle it
    Serial.println("System initialized. Starting first cycle in 10 seconds...");
    lastCycleTime = millis() - CYCLE_INTERVAL + 10000; // First run in 10 seconds
}

void loop()
{
    // Check if it's time for next cycle
    if (millis() - lastCycleTime >= CYCLE_INTERVAL) {
        cycleCount++;
        Serial.printf("\n=== Starting Cycle #%d ===\n", cycleCount);
        digitalWrite(LED_PIN, LOW); // LED on during operation

        bool success = performThingSpeakCycle();

        if (success) {
            Serial.println("=== Cycle Completed Successfully ===");
        } else {
            Serial.println("=== Cycle Failed ===");
        }

        // Put modem to sleep after cycle
        modem_sleep();
        digitalWrite(LED_PIN, HIGH); // LED off

        lastCycleTime = millis();
        Serial.printf("Next cycle in %d seconds\n", CYCLE_INTERVAL / 1000);
    }

    delay(1000); // Check every second
}

bool performThingSpeakCycle() {
    // Step 1: Wake up modem or power on if first time
    if (cycleCount == 1) {
        Serial.println("Step 1: Initial modem power on...");
        modem_on();
        if (!reply) {
            Serial.println("ERROR: Failed to power on modem");
            return false;
        }
    } else {
        Serial.println("Step 1: Waking up modem...");
        modem_wake();
    }

    // Step 2: Establish network connection
    Serial.println("Step 2: Establishing network connection...");
    if (!establishNetworkConnection()) {
        Serial.println("ERROR: Failed to establish network connection");
        return false;
    }

    // Step 3: Send data to ThingSpeak
    Serial.println("Step 3: Sending data to ThingSpeak...");
    if (!sendThingSpeakData()) {
        Serial.println("ERROR: Failed to send ThingSpeak data");
        return false;
    }

    return true;
}

bool establishNetworkConnection() {
    // Phase 1: Network Setup and Registration with retries
    for (int networkRetry = 0; networkRetry < MAX_NETWORK_RETRIES; networkRetry++) {
        Serial.printf("Network connection attempt %d/%d\n", networkRetry + 1, MAX_NETWORK_RETRIES);

        // 1. Check Signal Quality
        Serial.println("Checking signal quality...");
        String response = sendATCommand("AT+CSQ", AT_RESPONSE_TIMEOUT);
        if (response.indexOf("+CSQ:") >= 0) {
            int rssiStart = response.indexOf(":") + 1;
            int rssiEnd = response.indexOf(",", rssiStart);
            if (rssiEnd > rssiStart) {
                int rssi = response.substring(rssiStart, rssiEnd).toInt();
                Serial.printf("Signal strength: %d\n", rssi);
                if (rssi < 10) {
                    Serial.println("WARNING: Poor signal quality");
                }
            }
        }
        delay(2000);

        // 2. Force GPRS Mode (Critical for TCP/HTTP)
        Serial.println("Setting GPRS mode...");
        response = sendATCommand("AT+CNMP=13", AT_RESPONSE_TIMEOUT);
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to set GPRS mode");
            continue;
        }
        delay(3000);

        // 3. Check Network Registration (with extended timeout)
        Serial.println("Checking network registration...");
        bool registered = false;
        unsigned long regStartTime = millis();
        while (millis() - regStartTime < NETWORK_REG_TIMEOUT) {
            response = sendATCommand("AT+CREG?", 10000);
            if (response.indexOf("+CREG:") >= 0) {
                if (response.indexOf(",1") > 0 || response.indexOf(",5") > 0) {
                    Serial.println("Network registered successfully");
                    registered = true;
                    break;
                }
            }
            delay(5000); // Wait 5 seconds between checks
        }

        if (!registered) {
            Serial.println("Network registration failed");
            continue;
        }

        // 4. Set APN for network
        Serial.println("Setting APN...");
        String apnCommand = "AT+CGDCONT=1,\"IP\",\"" + String(APN) + "\"";
        response = sendATCommand(apnCommand, AT_RESPONSE_TIMEOUT);
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to set APN");
            continue;
        }
        delay(2000);

        // 5. Activate Data Connection
        Serial.println("Activating data connection...");
        response = sendATCommand("AT+CNACT=1,1", 30000); // Extended timeout
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to activate data connection");
            continue;
        }
        delay(5000);

        // 6. Verify IP Address Assignment
        Serial.println("Verifying IP address...");
        response = sendATCommand("AT+CNACT?", AT_RESPONSE_TIMEOUT);
        if (response.indexOf("+CNACT:") >= 0 && response.indexOf("1,1,\"") > 0) {
            Serial.println("IP address assigned successfully");

            // 7. Test DNS Resolution
            Serial.println("Testing DNS resolution...");
            response = sendATCommand("AT+CDNSGIP=\"api.thingspeak.com\"", 20000);
            if (response.indexOf("+CDNSGIP:") >= 0) {
                Serial.println("DNS resolution successful");
                return true;
            } else {
                Serial.println("DNS resolution failed, but continuing...");
                return true; // Continue even if DNS test fails
            }
        } else {
            Serial.println("No IP address assigned");
        }

        // Recovery sequence if this attempt failed
        Serial.println("Network setup failed, attempting recovery...");
        sendATCommand("AT+CNACT=1,0", 10000); // Deactivate context 1
        delay(5000);
    }

    Serial.println("All network connection attempts failed");
    return false;
}

bool sendThingSpeakData() {
    // Phase 2: HTTP Connection and Data Transmission with retries
    for (int httpRetry = 0; httpRetry < MAX_HTTP_RETRIES; httpRetry++) {
        Serial.printf("HTTP transmission attempt %d/%d\n", httpRetry + 1, MAX_HTTP_RETRIES);

        // 1. Configure HTTP Client
        Serial.println("Configuring HTTP client...");

        String response = sendATCommand("AT+SHCONF=\"URL\",\"http://api.thingspeak.com\"", AT_RESPONSE_TIMEOUT);
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to set HTTP URL");
            continue;
        }
        delay(1000);

        response = sendATCommand("AT+SHCONF=\"BODYLEN\",1024", AT_RESPONSE_TIMEOUT);
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to set body length");
            continue;
        }
        delay(1000);

        response = sendATCommand("AT+SHCONF=\"HEADERLEN\",350", AT_RESPONSE_TIMEOUT);
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to set header length");
            continue;
        }
        delay(2000);

        // 2. Establish HTTP Connection
        Serial.println("Establishing HTTP connection...");
        response = sendATCommand("AT+SHCONN", HTTP_TIMEOUT);
        if (response.indexOf("OK") < 0) {
            Serial.println("Failed to establish HTTP connection");
            // Try to disconnect and retry
            sendATCommand("AT+SHDISC", 5000);
            delay(3000);
            continue;
        }
        delay(3000);

        // 3. Send Data to ThingSpeak
        Serial.println("Sending data to ThingSpeak...");

        // Generate sample data (you can modify this to use real sensor data)
        float field1 = 25.5 + (cycleCount % 10); // Sample temperature
        float field2 = 60.2 + (cycleCount % 5);  // Sample humidity

        String dataRequest = "AT+SHREQ=\"/update?api_key=" + String(THINGSPEAK_API_KEY) +
                           "&field1=" + String(field1, 1) +
                           "&field2=" + String(field2, 1) + "\",1";

        response = sendHTTPRequest(dataRequest, HTTP_TIMEOUT);

        // 4. Parse response and read data
        if (response.indexOf("+SHREQ:") >= 0) {
            // Parse the response: +SHREQ: "GET",200,2
            // Find the line with +SHREQ:
            int shreqStart = response.indexOf("+SHREQ:");
            int lineEnd = response.indexOf("\n", shreqStart);
            String shreqLine = response.substring(shreqStart, lineEnd);

            Serial.printf("Parsing SHREQ line: %s\n", shreqLine.c_str());

            // Find the second comma (after "GET",)
            int firstComma = shreqLine.indexOf(",");
            int secondComma = shreqLine.indexOf(",", firstComma + 1);

            if (firstComma > 0 && secondComma > firstComma) {
                String statusCode = shreqLine.substring(firstComma + 1, secondComma);
                String byteCountStr = shreqLine.substring(secondComma + 1);

                statusCode.trim();
                byteCountStr.trim();

                Serial.printf("HTTP Status: %s, Byte Count: %s\n", statusCode.c_str(), byteCountStr.c_str());

                if (statusCode == "200") {
                    // 5. Read Response
                    int byteCount = byteCountStr.toInt();
                    if (byteCount > 0) {
                        String readCommand = "AT+SHREAD=0," + String(byteCount);
                        response = sendATCommand(readCommand, AT_RESPONSE_TIMEOUT);

                        if (response.indexOf("+SHREAD:") >= 0) {
                            Serial.println("Data sent successfully to ThingSpeak!");

                            // 6. Close HTTP Connection
                            Serial.println("Closing HTTP connection...");
                            sendATCommand("AT+SHDISC", 10000);
                            delay(2000);

                            return true;
                        }
                    }
                } else {
                    Serial.printf("HTTP request failed with status: %s\n", statusCode.c_str());
                }
            }
        } else {
            Serial.println("No valid HTTP response received");
        }

        // Cleanup for retry
        Serial.println("HTTP transmission failed, cleaning up...");
        sendATCommand("AT+SHDISC", 5000);
        delay(3000);

        // Recovery sequence
        if (httpRetry < MAX_HTTP_RETRIES - 1) {
            Serial.println("Attempting HTTP recovery...");
            sendATCommand("AT+CNACT=1,0", 10000); // Deactivate PDP context 1
            delay(3000);
            sendATCommand("AT+CNACT=1,1", 20000); // Reactivate PDP context 1
            delay(5000);
        }
    }

    Serial.println("All HTTP transmission attempts failed");
    return false;
}
